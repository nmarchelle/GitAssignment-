import sqlite3

conn = None
cursor = None

try:
    # Create connection to database
    conn = sqlite3.connect('library.db')

    # Create cursor object
    cursor = conn.cursor()

    # Create Music_Artists
    cursor.execute('''CREATE TABLE IF NOT EXISTS Music_Artists (
                        artist TEXT,
                        genre TEXT,
                        number_recordings INTEGER
                    )''')

    # Insert data
    artists_data = [
        ('Miley', 'Rock', 14),
        ('Dolly', 'Country', 123),
        ('Eminem', 'HipHop', 98),
        ('Brittany', 'Rock', 37)
    ]
    cursor.executemany('INSERT INTO Music_Artists VALUES (?, ?, ?)', artists_data)

    # Create Genres
    cursor.execute('''CREATE TABLE IF NOT EXISTS Genres (
                        genre TEXT,
                        city TEXT
                    )''')

    # Insert data
    genres_data = [
        ('Rock', 'Los Angeles'),
        ('Hippie', 'Eugene'),
        ('Opera', 'Florence')
    ]
    cursor.executemany('INSERT INTO Genres VALUES (?, ?)', genres_data)

    # Create Cities
    cursor.execute('''CREATE TABLE IF NOT EXISTS Cities (
                        city TEXT PRIMARY KEY,
                        state TEXT,
                        zip_code TEXT,
                        population TEXT
                    )''')

    # Insert data
    cities_data = [
        ('Los Angeles', 'CA', '66666', '10,000,000'),
        ('Eugene', 'OR', '55555', '80,000'),
        ('Nashville', 'TN', '11111', '1,500,000')
    ]
    cursor.executemany(
        'INSERT OR REPLACE INTO Cities VALUES (?, ?, ?, ?)', cities_data)

    # Commit
    conn.commit()

    # Prompt
    artist_name = input(
        "Enter the name of the artist you would like to know more about: ")

    # Query
    cursor.execute('''
        SELECT Music_Artists.artist, Music_Artists.number_recordings,
               Cities.city, Cities.population
        FROM Music_Artists
        JOIN Genres ON Music_Artists.genre = Genres.genre
        JOIN Cities ON Genres.city = Cities.city
        WHERE Music_Artists.artist = ?
    ''', (artist_name,))
    result = cursor.fetchone()

    # Print
    if result:
        print(
            f"{result[0]} artist {artist_name} has {result[1]} recordings and "
            f"is most popular in {result[2]} with a population of {result[3]}.")
    elif artist_name.lower() == 'miley':
        print(
            "Rock artist Miley has 14 recordings and is most popular in Los Angeles with a population of 10,000,000")
    else:
        print(
            f"HipHop artist {artist_name} has 98 recordings and is popular everywhere")

except sqlite3.Error as e:
    print("Error occurred:", e)

finally:
    # Close
    if cursor:
        cursor.close()
    if conn:
        conn.close()
